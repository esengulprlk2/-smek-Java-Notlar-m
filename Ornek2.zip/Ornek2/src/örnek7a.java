import java.util.Scanner;

public class �rnek7a {

	public static void main(String[] args) {


		//say�lar� kars�l�g�nda aylar� yaz
		Scanner sc = new Scanner(System.in);
		System.out.println("L�tfen mevsim giriniz");
		String mevsim = sc.next();
		int sayi= sc.nextInt();


		if(sayi==1) {
			System.out.println("OCAK");
		}else if(sayi==2) {
			System.out.println("�UBAT");
		}else if(sayi==3) {
			System.out.println("MART");
		}else if(sayi==4) 
			{System.out.println("N�SAN");
		
	}
	
	}








