
public class �RNEK11 {
	public static void main(String[] args) {

		/*
		 KARAR YAPILARI

		 - IF STATEMENT
		 - SWITCH-CASE YAPISI


		 */

		// IF KULLANIMLARI
		/*
		 if
		 if-else
		 if-else if-else
		 */

		int sayi = 1;
		if(sayi==1) {
			System.out.println("Say� de�i�ken de�eri 1'dir.");
		}

		int sayi2 = 5;
		if(sayi2==7) {
			System.out.println("Say� de�i�ken de�eri 7'dir.");
		}
		else if(sayi2 == 5) {
			System.out.println("Say�2'nin de�i�ken de�eri 5'dir.");
		}
// control a control iye bas�nca kodlar� d�zenlyo
		//if yaz�p kontrol ve bosluk a bas�nca otomat�k yaz�yor kod sat�r�n� 
		
		else {
			System.out.println("Say�2 ne 7 ne de 5 de�ildir.");
		}


	}


}
//-------------------------------------------------------------------------------------------------------
