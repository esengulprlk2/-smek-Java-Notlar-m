import java.util.Scanner;

public class �rnek4a {
	public static void main(String[] args) {


		/*D��ar�dan iki say� ve i�lem iste, i�lem de�eri (topla,��kar,�arp,b�l olabilsin )
		 *  buna g�re de i�lemi ger�ekle�tirip, i�lem sonucunu ekrana yazd�rs�n.
		 */
		Scanner sc = new Scanner(System.in);
		System.out.println("L�tfen i�lem giriniz(topla,��kar,�arp,b�l) ");
		String islem = sc.next();
		System.out.println("L�tfen 1.say�y� Giriniz" );

		int sayi1 = sc.nextInt();

		System.out.println("L�tfen 2.say�y� Giriniz" );
		int sayi2 = sc.nextInt();

		int sonuc = 0;
		if("topla".equals(islem)) {
			sonuc= sayi1+sayi2;
			System.out.println("Toplama i�lemi sonucu: "+sonuc);
		}else if("��kar".equals(islem)) {
			sonuc= sayi1-sayi2;
			System.out.println("��karma i�lemi sonucu: "+sonuc);
		}else if("�arp".equals(islem)) {
			sonuc= sayi1*sayi2;
			System.out.println("�arpma i�lemi sonucu: "+sonuc);
		}else if("b�l".equals(islem)) {
			sonuc= sayi1/sayi2;
			System.out.println("B�lme i�lemi sonucu: "+sonuc);
		}else {
			System.out.println("Hatal� i�lem se�tiniz ! ");
		}




	}
}
//---------------------------------------------------------------------------------------------------------------