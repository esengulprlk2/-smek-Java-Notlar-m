import java.util.Scanner;

public class �rnek8a {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("L�tfen mevsim giriniz");
		String mevsim = sc.next();






		switch (mevsim) { //switch case
		case "sonbahar": //caseden sonra break eklemek zorundas�n ve iki nokta koymas�l�s�n.
			System.out.println("Ekim, Kas�m, Aral�k");
			break; //d�ng�den c�kmak �c�n kullan�l�r.
		case "k��":
			
			
			
			System.out.println("Ocak, �ubat, Mart");
			break;
		case "ilkbahar":
			System.out.println("Nisan, May�s, Haziran");
			break;
		case "yaz":
			System.out.println("Temmuz, A�ustos, Eyl�l");
			break;
		default:
			System.out.println("Hatal� Mevvsim Giri�i");
			break;
		}



	}

}
