import java.util.Scanner;

public class �RNEK5 {
	public static void main(String[] args) {
		//DI�ARDAN 2 �NT DE�ER� G�R, EKRANA YAZDIR
		
		Scanner sc = new Scanner(System.in); //kullan�c�dan veri alma
		
		System.out.println("L�tfen 1.say�y� Giriniz" );// syso yaz�p kontrol ve bosluk tusuna bas�nca d�rek yaz�yor bu cumley�
		
		int sayi1 = sc.nextInt(); //bunu kullanab�lmmek �c�n yukar�dak� Scanner sc = new Scanner(System.in); � yazmak zorunday�z.
		
		System.out.println("L�tfen 2.say�y� Giriniz" );// = ile bir de�i�kene de�er atamas� yapabiliriz
		int sayi2 = sc.nextInt();//klavyeden sayi giri�i beklemek i�in
		
		//ekranda yaz� g�stermek i�in
		System.out.println("1.say�: " +sayi1);
		System.out.println("2.say�: " +sayi2);
		
		
		
		
		
	}
}
