import java.util.Scanner;

public class �rnek2a {
	public static void main(String[] args) {
		
		
		//basit veri tipleri == ile k�yaslan�r. String de�erleri k�yaslanmas� i�in string s��f�n�n equals metodu kullan�lmas� gerek�r.
		//KULLANICI G�R��L� ��LEM
		
		String defaultUsername = "root";
		String defaultPassword = "abcd";
		
		// scanner nesnesi ile d��ar�dan veri giri�i sa�layal�m.
		Scanner sc = new Scanner(System.in); //KONTROL BOSLUGA BAS KENDINI IMPORT EDER (ALTI CIZGILI HATA VERINCE)
		
		
		System.out.println("Kullan�c� ad�n� giriniz: ");
		String username = sc.next();
		System.out.println("�ifre giriniz: ");
		String password = sc.next();
		
		
	//	if(username==defaultUsername && password==defaultPassword) -----stringleri == yapamay�z o y�zden alttak�n� yazcaz bu sat�r yanl�s
		if(username.equals(defaultUsername) && password.equals(defaultPassword))
		{
			System.out.println("Ho�geldiniz");
			//D��ar�dan girdi�imiz kullan�c� ad� root yada �ifresi abcd ise
		}else {
			System.out.println("Hatal� giri�"); 
			//D��ar�dan girdi�imiz kullan�c� ad� root yada �ifresi abcd de�il ise
		}
		
		
		
		
		
	}
}
//------------------------------------------------------------------------------------------------------
//d�sar�dan ki�inin yas�n� iste