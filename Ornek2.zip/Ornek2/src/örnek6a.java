import java.util.Scanner;

public class �rnek6a {

	public static void main(String[] args) {
		//D��ar�dan mevsimin ismini isteyin, mevsime ait aylar� ekrana yazd�r�n.
		Scanner sc = new Scanner(System.in);
		System.out.println("L�tfen mevsim giriniz");
		String mevsim = sc.next();
		
		if("sonbahar".equalsIgnoreCase(mevsim))//b�y�k k���k harf fark�n� ortadan kald�rmak �c�n kullan�l�r(equalsIgnoreCase)
			//ifin i�inde sadece bir sat�r varsa s�sl� paranteze gerek yoktur.�oklu sat�rlar �c�n gerek var.
System.out.println("Ekim, Kas�m, Aral�k");
		else if("k��".equalsIgnoreCase(mevsim))
			System.out.println("Ocak, �ubat, Mart");
		else if("ilkbahar".equalsIgnoreCase(mevsim))
			System.out.println("Nisan, May�s, Haziran");
		else if("yaz".equalsIgnoreCase(mevsim))
			System.out.println("Temmuz, A�ustos, Eyl�l");
		else
			System.out.println("Hatal� Mevsim Giri�i");
		
		

	}

}
//---------------------------------------------------------------------------