import java.util.Scanner;

public class �rnek5a {

	public static void main(String[] args) {

		// �� ��E �F KULLANIMI

		Scanner sc = new Scanner(System.in);
		System.out.println("Ad�n�z� giriniz");
		String ad = sc.next();
		System.out.println("Soyad�n�z� giriniz");
		String soyad =sc.next();

		if("�ER�F".equals(ad) && "G�NG�R".equals(soyad) ) {
System.out.println("L�tfen ya��n�z� giriniz");
			int yas =sc.nextInt();
			if(yas==25) {
				System.out.println("Ya��n�z 25'dir.");
				}
				else {
					System.out.println("Ya��n�z 25 de�ildir.");

				}
			
			}else {
				System.out.println("HATALI B�LG� G�R���");
			}
		}
	}

//------------------------------------------------------------------------------------------------


