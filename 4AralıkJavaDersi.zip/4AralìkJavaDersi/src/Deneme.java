import java.util.Scanner;

public class Deneme {

	public static void main(String[] args) {
		 Scanner sc 

	}

}
