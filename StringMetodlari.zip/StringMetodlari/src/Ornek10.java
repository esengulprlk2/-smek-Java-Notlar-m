
public class Ornek10 {

	public static void main(String[] args) {
		// 
		
		String str = "T�RK�YE B�Y�K M�LLET MECL�S�";
		
		String[] dizi = str.split(" ");
		
		 System.out.println(dizi[0]);
		 System.out.println(dizi[1]);
		 System.out.println(dizi[2]);
		 System.out.println(dizi[3]);
		 
		 
		 System.out.println("-----");
		 
		 String meyveler = "elma,armut,kiraz,nar, portakal";
		 
			String[] meyve = meyveler.split(",");
			
			 System.out.println(meyve[0]);
			 System.out.println(meyve[3]);
			 
			 
			 System.out.println("-----");
			 
			 
			 
			 String email = "contact@serifgungor.com";
			 
				String[] mail = email.split("@");
				
				 System.out.println(mail[0]);
				 System.out.println(mail[1]);
				 
				

	}

}
