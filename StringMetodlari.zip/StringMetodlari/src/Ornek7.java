
public class Ornek7 {

	public static void main(String[] args) {
	 
		//length kullan�m�
		
		String turkceENUzunKelime = "�ekoslovakyal�la�t�ramad�klar�m�zdanm�s�n�z";
		System.out.println("Kelimenin uzunlu�u:"+turkceENUzunKelime.length());

	}

}
