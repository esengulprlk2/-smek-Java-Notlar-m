
public class Ornek2 {

	public static void main(String[] args) {
		// toUppperCase, toLowerCase metotlar�
		
		String okul = "Fatih Bili�im Okulu";
		
		System.out.println("K���k Harfe �evirme: "+okul.toLowerCase());
		System.out.println("B�y�k Harfe �evirme: "+okul.toUpperCase());
        System.out.println("Orjinal metin: "+okul);
        
        okul = okul.toUpperCase() ;
        System.out.println("Okul de�i�keninin g�ncel de�eri: "+okul);
        
	}

}
