
public class Ornek5 {

	public static void main(String[] args) {
		
		//equals ve equalsIgnoreCase kullan�mlar�
		
		String sehir = "�stanbul";
		
		if ("istanbul".contentEquals(sehir)) {
			
			System.out.println("�ehir istanbuldur.");
		}else {
			System.out.println("�ehir istanbul de�ildir.");
			
		}
		
		
		String sehir1 = "ANKARA";
		
		if ("ankara".equalsIgnoreCase(sehir1)) {
			
			System.out.println("�ehir ankara'd�r.");
			
		} else {
			
			System.out.println("�ehir ankara de�ildir.");
		}
		
		/*
		equalsIgnoreCase ile K���k /B�y�k harf farketmeksizin de�i�ken de�eri sorgulan�r
		
		 K���k /B�y�k harf ile yaz�lmas� �nemli de�ildir.Yeter ki ifade ayn� olsun.
		 */

	}

}
