
public class Ornek6 {

	public static void main(String[] args) {
		
		
		String website = "www.esengulparlak.com";
		
		
		if (website.startsWith("www.")) {
			
			System.out.println("Website adresi www. ile ba�lamaktad�r.");
		} else {
			
			System.out.println("Website adresi www. ile ba�lamamaktad�r.");
		}
		
		
	if (website.endsWith(".com")) {
			
			System.out.println("Website adresi .com ile bitmektedir.");
		} else {
			
			System.out.println("Website adresi .com ile bitmemektedir.");
		}
		

	}

}
