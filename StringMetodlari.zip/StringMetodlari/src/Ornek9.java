
public class Ornek9 {

	public static void main(String[] args) {
		
		// replace kullan�m�
		
		/*
		 Bir kelimeyi yada karakteri farkl� bir de�er ile de�i�tirmek i�in kullan�l�r
		 
		-replace metodu i�erisine iki parametre bekler.
		
		 */
		
		String metin = "BEN�M ADIM �SMEK";
				
		System.out.println(metin);
		
		metin = metin.replace("�SMEK","�ER�F");
		
		System.out.println(metin);

	}

}
