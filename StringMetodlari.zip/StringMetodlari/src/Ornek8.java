
public class Ornek8 {

	public static void main(String[] args) {
		
		
		//trim metodu kullan�m�
		
		String metin = " MERHABA JAVA PRORAMLAMA ";
		
		System.out.println(metin);
		
		metin = metin.trim();
		
		System.out.println(metin);
		
		

	}

}
