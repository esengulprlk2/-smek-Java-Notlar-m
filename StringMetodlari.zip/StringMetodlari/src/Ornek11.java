
public class Ornek11 {

	public static void main(String[] args) {
		
		// isEmpty metodu kullan�m�
		
		String str = "";
		
		if (str.isEmpty()) {			
			
			System.out.println("str de�i�ken de�eri bo�tur");
		}
		
		if (!str.isEmpty()) {                   // bu k�s�m else gibi �al���r.
			
			System.out.println("str de�i�ken de�eri doludur");
		}
		
		
		System.out.println("------");
		
		
		boolean b = str.isEmpty();  // yukardaki if'li yap�n�n ayn�s� gibi �al���r,
		
		if(b) {			
			
			System.out.println("str de�i�ken de�eri bo�tur");
		}
		
		if(!b) {                   // bu k�s�m else gibi �al���r.
			
			System.out.println("str de�i�ken de�eri doludur");
		}
		
		
		

	}

}
