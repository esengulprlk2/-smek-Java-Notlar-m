
public class Ornek3 {

	public static void main(String[] args) {
		// SUBSTR�NG METODU
		
		/*
		  Belirtilen ba�lang�� ve biti� indisleri aras�ndaki de�erlerin okunmas�n� sa�layan string metodudur.
		  
		  indeksler s�f�rdan ba�lar �r: yunanistandaki y 0.
		 */
		
		String metin = "YUNAN�STANBULGAR�STAN"; //5,13
		
		String s = metin.substring (5,13);
		System.out.println(s);

	}

}
 